// OpenWeather API 키
const apiKey = 'ca3c57d21ef7591d018e467393935f00';
    
// API 요청 URL 생성
const city = 'Seoul';
const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

// HTML 요소 가져오기
const weatherDataContainer = document.getElementById('weatherData');

// API 요청 및 처리
fetch(apiUrl)
    .then(response => response.json())
    .then(data => {
        // API 응답 데이터를 활용하여 정보 출력
        const temperature = data.main.temp;
        const description = data.weather[0].description;
        const icon = data.weather[0].icon;

        const weatherHTML = `
            <h2>Current Weather in ${city}</h2>
            <p>Temperature: ${temperature}°C</p>
            <p>Description: ${description}</p>
            <img src="'https://img.freepik.com/free-photo/close-up-portrait-on-beautiful-cat_23-2149214373.jpg';alt="${description}">
        `;

        weatherDataContainer.innerHTML = weatherHTML;
    })
    .catch(error => {
        console.error('Error fetching weather data:', error);
        weatherDataContainer.innerText = 'Failed to fetch weather data';
    });